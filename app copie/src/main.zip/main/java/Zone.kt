package com.example.imagenavigator

import android.graphics.RectF
import org.json.JSONObject
import org.json.JSONArray

// Représente une zone cliquable avec sa position et l'image liée
// rect définit le rectangle de la zone (x1, y1, x2, y2)
data class Zone(
    val rect: RectF,
    var linkedImage: String
)

// Fonction utilitaire pour extraire une liste de Zone depuis un JSONObject
fun parseZonesFromJson(zonesObject: JSONObject): Map<String, List<Zone>> {
    val zoneMap = mutableMapOf<String, List<Zone>>()

    for (imageName in zonesObject.keys()) {
        val value = zonesObject.opt(imageName)
        if (value is JSONArray) {
            val zones = mutableListOf<Zone>()
            for (i in 0 until value.length()) {
                val zoneJson = value.getJSONObject(i)
                val x1 = zoneJson.getDouble("x1").toFloat()
                val y1 = zoneJson.getDouble("y1").toFloat()
                val x2 = zoneJson.getDouble("x2").toFloat()
                val y2 = zoneJson.getDouble("y2").toFloat()
                val linkedImage = zoneJson.getString("linkedImage")
                zones.add(Zone(RectF(x1, y1, x2, y2), linkedImage))
            }
            zoneMap[imageName] = zones
        } else {
            // Astuce : si ce n'est pas un JSONArray, on ignore ou on initialise une liste vide
            zoneMap[imageName] = emptyList()
        }
    }

    return zoneMap
}
