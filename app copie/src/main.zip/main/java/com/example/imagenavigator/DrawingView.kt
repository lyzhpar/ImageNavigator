package com.example.imagenavigator

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View

class DrawingView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    val zones: MutableList<Zone> = mutableListOf()
    var currentImageName: String = ""
    private var currentRect: RectF? = null
    private var zoneClickListener: ((Zone) -> Unit)? = null

    private val fillPaint = Paint().apply {
        style = Paint.Style.FILL
        color = 0x3333CC33 // vert très léger pour le fond temporaire
    }

    private val strokePaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.GREEN
    }

    fun updateCurrentRect(startX: Float, startY: Float, endX: Float, endY: Float) {
        Log.d("DrawingView", "updateCurrentRect called with: start=($startX, $startY), end=($endX, $endY)")
        currentRect = RectF(
            minOf(startX, endX),
            minOf(startY, endY),
            maxOf(startX, endX),
            maxOf(startY, endY)
        )
        invalidate()
    }

    fun finalizeCurrentRect(drawableWidth: Float, drawableHeight: Float): ZoneRelatif? {
        val rect = currentRect
        Log.d("DrawingView", "finalizeCurrentRect called. Result=$rect")
        currentRect = null
        invalidate()
        return rect?.takeIf { it.width() > 10 && it.height() > 10 }?.let {
            val x1 = it.left / drawableWidth
            val y1 = it.top / drawableHeight
            val x2 = it.right / drawableWidth
            val y2 = it.bottom / drawableHeight
            val zone = Zone(it, "")
            zones.add(zone)
            ZoneRelatif(
                x1 = x1,
                y1 = y1,
                x2 = x2,
                y2 = y2,
                linkedImage = "",
                imageSource = currentImageName
            )
        }
    }

    fun setOnZoneClickListener(listener: (Zone) -> Unit) {
        Log.d("DrawingView", "Zone click listener set")
        zoneClickListener = listener
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        Log.d("DrawingView", "Touch event: action=${event.action}, x=${event.x}, y=${event.y}")
        if (event.action == MotionEvent.ACTION_DOWN) {
            val clickedZone = zones.find { it.rect.contains(event.x, event.y) }
            if (clickedZone != null) {
                Log.d("DrawingView", "Zone clicked: ${clickedZone.rect}")
                zoneClickListener?.invoke(clickedZone)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        Log.d("DrawingView", "onDraw called with ${zones.size} zones. currentRect=$currentRect")
        for (zone in zones) {
            Log.d("DrawingView", "Drawing zone: ${zone.rect}")
            canvas.drawRect(zone.rect, strokePaint)
        }
        currentRect?.let {
            canvas.drawRect(it, fillPaint)
            canvas.drawRect(it, strokePaint)
        }
    }
}