package com.example.imagenavigator

import android.graphics.RectF
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File

data class ZoneRelatif(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val linkedImage: String, val imageSource: String)

class NavigatorActivity : AppCompatActivity() {
    private val zones = mutableListOf<Zone>()
    private val zoneRelatifs = mutableListOf<ZoneRelatif>()
    private val history = mutableListOf<String>()
    private var lastClickX = 0f
    private var lastClickY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigator)
        val imageView = findViewById<ImageView>(R.id.navImageView)

        if (savedInstanceState != null) {
            val zonesString = savedInstanceState.getString("zones")
            if (zonesString != null) {
                val zonesArray = org.json.JSONArray(zonesString)
                for (i in 0 until zonesArray.length()) {
                    val obj = zonesArray.getJSONObject(i)
                    val imageName = obj.getString("imageName")
                    val drawable = ContextCompat.getDrawable(this, resources.getIdentifier(imageName, "drawable", packageName))
                    zoneRelatifs.add(
                        ZoneRelatif(
                            obj.getDouble("x1").toFloat(),
                            obj.getDouble("y1").toFloat(),
                            obj.getDouble("x2").toFloat(),
                            obj.getDouble("y2").toFloat(),
                            obj.getString("linkedImage"),
                            obj.getString("imageSource")
                        )
                    )
                }
            }
        }
        val restoredImageName = savedInstanceState?.getString("currentImageName") ?: "image1"
        supportActionBar?.hide()
        Log.d("NavigatorActivity", "NavigatorActivity started")

        val backButton = findViewById<ImageButton>(R.id.backButton)

        imageView.isClickable = true
        Log.d("NavigatorActivity", "ImageView isClickable: ${imageView.isClickable}")

        loadConfig()
        setImage(imageView, restoredImageName)
        history.add(restoredImageName)
        Log.d("NavigatorActivity", "Image initiale définie sur $restoredImageName")

        imageView.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_DOWN) {
                lastClickX = event.x
                lastClickY = event.y
                Log.d("NavigatorActivity", "Touch captured at $lastClickX, $lastClickY")
            }
            false
        }

        imageView.setOnClickListener {
            val adjustedCoords = adjustCoordinates(imageView, lastClickX, lastClickY)
            val x = adjustedCoords[0]
            val y = adjustedCoords[1]
            Log.d("NavigatorActivity", "Adjusted click at $x, $y")
            Log.d("NavigatorActivity", "Clic sur l'image en coordonnées ajustées: x=$x, y=$y — zones disponibles: ${zones.size}")
            var zoneClicked = false
            for (zone in zones) {
                Log.d("NavigatorActivity", "Checking zone: ${zone.rect}")
                if (zone.rect.contains(x, y)) {
                    setImage(imageView, zone.linkedImage)
                    Toast.makeText(this, "Navigated to ${zone.linkedImage}", Toast.LENGTH_SHORT).show()
                    history.add(zone.linkedImage)
                    Log.d("NavigatorActivity", "Navigated to ${zone.linkedImage}")
                    zoneClicked = true
                    break
                } else {
                    Log.d("NavigatorActivity", "Click outside zone: ${zone.rect}")
                }
            }
            if (!zoneClicked) {
                Log.d("NavigatorActivity", "Aucune zone cliquée détectée à $x, $y")
            }
        }

        backButton.setOnClickListener {
            if (history.size > 1) {
                history.removeAt(history.lastIndex)
                val previousImage = history.last()
                setImage(imageView, previousImage)
                Toast.makeText(this, "Returned to $previousImage", Toast.LENGTH_SHORT).show()
                Log.d("NavigatorActivity", "Returned to $previousImage")
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val zonesJson = org.json.JSONArray()
        for (zone in zoneRelatifs) {
            val obj = org.json.JSONObject()
            obj.put("x1", zone.x1)
            obj.put("y1", zone.y1)
            obj.put("x2", zone.x2)
            obj.put("y2", zone.y2)
            obj.put("linkedImage", zone.linkedImage)
            obj.put("imageSource", zone.imageSource)
            obj.put("imageName", findViewById<TextView>(R.id.imageNameText).text.toString())
            zonesJson.put(obj)
        }
        outState.putString("zones", zonesJson.toString())
        outState.putString("currentImageName", findViewById<TextView>(R.id.imageNameText).text.toString())
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d("NavigatorActivity", "Configuration changed: ${newConfig.orientation}")
        val imageView = findViewById<ImageView>(R.id.navImageView)
        val imageName = findViewById<TextView>(R.id.imageNameText).text.toString()
        Log.d("NavigatorActivity", "Rotation détectée. Rechargement de l'image $imageName")
        Log.d("NavigatorActivity", "Appel setImage suite à rotation avec image: $imageName")
        setImage(imageView, imageName)
    }

    private fun setImage(imageView: ImageView, imageName: String) {
        Log.d("NavigatorActivity", "Processing image: $imageName")
        val resId = resources.getIdentifier(imageName, "drawable", packageName)
        if (imageName.isBlank() || resId == 0) {
            Log.e("NavigatorActivity", "Nom d'image invalide ou non trouvé: '$imageName'")
            Toast.makeText(this, "Image invalide : '$imageName'", Toast.LENGTH_SHORT).show()
            imageView.setImageResource(R.drawable.image1)
            return
        }
        imageView.setImageResource(resId)
        Log.d("NavigatorActivity", "Image '$imageName' chargée avec succès (resId=$resId)")

        Log.d("NavigatorActivity", "setImage() appelé avec imageName=$imageName")

        val imageNameText = findViewById<TextView>(R.id.imageNameText)
        imageNameText.text = ""

        Log.d("NavigatorActivity", "Début du post pour mise à jour des zones")
        imageView.post {
            val drawable = imageView.drawable ?: return@post
            val imageMatrix = imageView.imageMatrix
            val drawableRect = RectF(0f, 0f, drawable.intrinsicWidth.toFloat(), drawable.intrinsicHeight.toFloat())
            val viewRect = RectF()
            imageMatrix.mapRect(viewRect, drawableRect)

            zones.clear()
            Log.d("NavigatorActivity", "Recalcul des zones pour l'image $imageName (viewRect=$viewRect)")

            var zoneCount = 0
            for (zone in zoneRelatifs) {
                Log.d("NavigatorActivity", "Zone candidate: $zone")
                val rect = RectF(
                    viewRect.left + zone.x1 * viewRect.width(),
                    viewRect.top + zone.y1 * viewRect.height(),
                    viewRect.left + zone.x2 * viewRect.width(),
                    viewRect.top + zone.y2 * viewRect.height()
                )
                Log.d("NavigatorActivity", " → Calculée : $rect")

                // Ajoute la zone uniquement si l'image affichée correspond
                if (zone.linkedImage.isNotBlank() && zone.imageSource == imageName) {
                    zones.add(Zone(rect, zone.linkedImage))
                    zoneCount++
                }
            }

            Log.d("NavigatorActivity", "Nombre de zones ajoutées : $zoneCount")

            val overlay = imageView.overlay
            overlay.clear()
            Log.d("NavigatorActivity", "Overlay clear() appelé")
            for (zone in zones) {
                val debugRect = zone.rect
                val shape = android.graphics.drawable.ShapeDrawable(android.graphics.drawable.shapes.RectShape())
                shape.paint.color = android.graphics.Color.argb(100, 0, 255, 0)
                shape.setBounds(debugRect.left.toInt(), debugRect.top.toInt(), debugRect.right.toInt(), debugRect.bottom.toInt())
                overlay.add(shape)
            }

            Log.d("NavigatorActivity", "Nombre de zones affichées en overlay : ${zones.size}")
        }
        Log.d("NavigatorActivity", "setImage terminé pour $imageName")
    }

    private fun adjustCoordinates(imageView: ImageView, x: Float, y: Float): FloatArray {
        val drawable = imageView.drawable ?: return floatArrayOf(x, y)

        val matrix = imageView.imageMatrix
        val drawableRect = RectF(0f, 0f, drawable.intrinsicWidth.toFloat(), drawable.intrinsicHeight.toFloat())
        val viewRect = RectF()
        matrix.mapRect(viewRect, drawableRect)

        if (!viewRect.contains(x, y)) {
            return floatArrayOf(-1f, -1f)
        }

        val relativeX = (x - viewRect.left) / viewRect.width()
        val relativeY = (y - viewRect.top) / viewRect.height()

        val drawableX = drawable.intrinsicWidth * relativeX
        val drawableY = drawable.intrinsicHeight * relativeY

        Log.d("NavigatorActivity", "adjustCoordinates: ($x, $y) → drawable=($drawableX, $drawableY)")
        return floatArrayOf(drawableX, drawableY)
    }

    private fun loadConfig() {
        val file = File(filesDir, "config.json")
        if (file.exists()) {
            val jsonString = file.readText()
            Log.d("NavigatorActivity", "JSON brut: $jsonString")
            val json = JSONObject(jsonString)
            if (!json.has("zones")) {
                Log.e("NavigatorActivity", "Config file is missing 'zones'")
                return
            }
            val zonesObject = json.getJSONObject("zones")
            Log.d("NavigatorActivity", "'zones' object trouvé avec ${zonesObject.length()} images")

            val startImage = json.optString("startImage", "image1")

            zones.clear()
            zoneRelatifs.clear()
            zonesObject.keys().forEach { imageName ->
                Log.d("NavigatorActivity", "Traitement des zones pour $imageName")
                try {
                    val value = zonesObject.getJSONArray(imageName)
                    Log.d("NavigatorActivity", "  → ${value.length()} zones détectées")
                    Log.d("NavigatorActivity", "Zones pour $imageName: ${value.length()} zones")
                    for (i in 0 until value.length()) {
                        val zoneJson = value.getJSONObject(i)
                        val linkedImage = zoneJson.getString("linkedImage")
                        val drawable = ContextCompat.getDrawable(this, resources.getIdentifier(imageName, "drawable", packageName))
                        if (drawable == null) {
                            Log.e("NavigatorActivity", "  ⚠ Drawable introuvable pour $imageName — zone ignorée")
                            return@forEach
                        }
                        val imageWidth = drawable.intrinsicWidth.toFloat()
                        val imageHeight = drawable.intrinsicHeight.toFloat()
                        val absX1 = zoneJson.getDouble("x1").toFloat()
                        val absY1 = zoneJson.getDouble("y1").toFloat()
                        val absX2 = zoneJson.getDouble("x2").toFloat()
                        val absY2 = zoneJson.getDouble("y2").toFloat()

                        val isRelative = absX1 in 0f..1f && absY1 in 0f..1f && absX2 in 0f..1f && absY2 in 0f..1f
                        val relX1 = if (isRelative) absX1 else absX1 / imageWidth
                        val relY1 = if (isRelative) absY1 else absY1 / imageHeight
                        val relX2 = if (isRelative) absX2 else absX2 / imageWidth
                        val relY2 = if (isRelative) absY2 else absY2 / imageHeight

                        zoneRelatifs.add(
                            ZoneRelatif(relX1, relY1, relX2, relY2, linkedImage, imageName)
                        )
                        Log.d("NavigatorActivity", "Coordonnées converties → x1=$relX1, y1=$relY1, x2=$relX2, y2=$relY2")
                        Log.d("NavigatorActivity", "Zone ajoutée: ${zoneRelatifs.last()}")
                        Log.d("NavigatorActivity", "  → Zone ajoutée pour $imageName vers $linkedImage")
                    }
                } catch (e: Exception) {
                    Log.w("NavigatorActivity", "Error parsing zones for $imageName: ${e.message}")
                }
            }

            Log.d("NavigatorActivity", "Config loaded: $zones")
            Log.d("NavigatorActivity", "Nombre total de zoneRelatifs : ${zoneRelatifs.size}")
        } else {
            Log.d("NavigatorActivity", "Config file not found")
        }
    }
}