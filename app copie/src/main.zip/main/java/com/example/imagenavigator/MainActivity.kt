package com.example.imagenavigator

import android.content.Intent
import android.graphics.RectF
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import android.widget.ImageView


class MainActivity : AppCompatActivity() {
    private val imageZones = mutableMapOf<String, MutableList<Zone>>()
    private var currentImage = "image1"
    private val availableImages: List<String> by lazy {
        val fields = R.drawable::class.java.fields
        fields.mapNotNull { field ->
            try {
                field.name
            } catch (e: Exception) {
                null
            }
        }.filter { it != "ic_launcher_background" && it != "ic_launcher_foreground" } // filtre optionnel
    }
    private var startX = 0f
    private var startY = 0f
    private var drawing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_main)

        val imageView = findViewById<ImageView>(R.id.configImageView)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val drawingView = findViewById<DrawingView>(R.id.drawingView)
        val thumbnailsContainer = findViewById<LinearLayout>(R.id.thumbnailsContainer)

        imageView.setImageResource(R.drawable.image1)
        imageView.isClickable = true
        Log.d("MainActivity", "ImageView isClickable: ${imageView.isClickable}")

        availableImages.forEach { name ->
            val thumbnailImageView = ImageView(this).apply {
                val imageResId = resources.getIdentifier(name, "drawable", packageName)
                setImageResource(imageResId)
                layoutParams = LinearLayout.LayoutParams(200, 200).apply {
                    setMargins(8, 8, 8, 8)
                }
                setOnClickListener {
                    currentImage = name
                    imageView.setImageResource(imageResId)
                    drawingView.zones = imageZones.getOrPut(name) { mutableListOf() }
                    drawingView.invalidate()
                }
            }
            thumbnailsContainer.addView(thumbnailImageView)
        }

        imageView.setOnTouchListener { _, event ->
            Log.d("MainActivity", "Touch event received: ${event.action}")
            val adjustedCoords = adjustCoordinates(imageView, event.x, event.y)
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    startX = adjustedCoords[0]
                    startY = adjustedCoords[1]
                    drawing = true
                    Log.d("MainActivity", "Start drawing at $startX, $startY")
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (drawing) {
                        drawingView.updateCurrentRect(startX, startY, adjustedCoords[0], adjustedCoords[1])
                    }
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (drawing) {
                        if (Math.abs(adjustedCoords[0] - startX) < 0.01 || Math.abs(adjustedCoords[1] - startY) < 0.01) {
                            drawing = false
                            return@setOnTouchListener true
                        }
                        val imageViewWidth = imageView.width.toFloat().takeIf { it > 0 } ?: 1f
                        val imageViewHeight = imageView.height.toFloat().takeIf { it > 0 } ?: 1f
                        val rect = drawingView.finalizeCurrentRect(imageViewWidth, imageViewHeight)
                        rect?.let {
                            val imageNames = availableImages
                            val linkedImageDialogLayout = LinearLayout(this@MainActivity).apply {
                                orientation = LinearLayout.HORIZONTAL
                                setPadding(16, 16, 16, 16)
                                gravity = android.view.Gravity.CENTER
                            }

                            val linkedImageScrollView = android.widget.HorizontalScrollView(this@MainActivity).apply {
                                addView(linkedImageDialogLayout)
                            }

                            val alertDialog = android.app.AlertDialog.Builder(this@MainActivity)
                                .setTitle("Choisis une image liée")
                                .setView(linkedImageScrollView)
                                .create()

                            imageNames.forEach { name ->
                                val imageResId = resources.getIdentifier(name, "drawable", packageName)

                                val imageContainer = LinearLayout(this@MainActivity).apply {
                                    orientation = LinearLayout.VERTICAL
                                    gravity = Gravity.CENTER
                                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                                        setMargins(16, 0, 16, 0)
                                    }
                                }

                                val thumbnailImageView = ImageView(this@MainActivity).apply {
                                    setImageResource(imageResId)
                                    layoutParams = LinearLayout.LayoutParams(200, 200)
                                    background = ContextCompat.getDrawable(this@MainActivity, android.R.drawable.dialog_holo_light_frame)
                                    setPadding(8, 8, 8, 8)

                                    setOnClickListener {
                                        this.setBackgroundColor(android.graphics.Color.parseColor("#FF9800")) // orange

                                        postDelayed({
                                            val zone = Zone(RectF(rect.x1, rect.y1, rect.x2, rect.y2), name)
                                            val list = imageZones.getOrPut(currentImage) { mutableListOf() }
                                            list.add(zone)
                                            drawingView.zones = list
                                            drawingView.invalidate()
                                            drawingView.setOnZoneClickListener { clickedZone ->
                                                val modifyImageDialogLayout = LinearLayout(this@MainActivity).apply {
                                                    orientation = LinearLayout.HORIZONTAL
                                                    setPadding(16, 16, 16, 16)
                                                    gravity = android.view.Gravity.CENTER
                                                }

                                                val modifyImageScrollView = android.widget.HorizontalScrollView(this@MainActivity).apply {
                                                    addView(modifyImageDialogLayout)
                                                }

                                                val modifyAlertDialog = android.app.AlertDialog.Builder(this@MainActivity)
                                                    .setTitle("Modifier l'image liée")
                                                    .setView(modifyImageScrollView)
                                                    .create()

                                                val deleteButton = android.widget.Button(this@MainActivity).apply {
                                                    text = getString(R.string.delete_zone_button_text)
                                                    setOnClickListener {
                                                        imageZones[currentImage]?.remove(clickedZone)
                                                        drawingView.zones = imageZones[currentImage] ?: mutableListOf()
                                                        drawingView.invalidate()
                                                        modifyAlertDialog.dismiss()
                                                    }
                                                }
                                                modifyImageDialogLayout.addView(deleteButton)

                                                availableImages.forEach { name ->
                                                    val imageResId = resources.getIdentifier(name, "drawable", packageName)

                                                    val imageContainer = LinearLayout(this@MainActivity).apply {
                                                        orientation = LinearLayout.VERTICAL
                                                        gravity = Gravity.CENTER
                                                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                                                            setMargins(16, 0, 16, 0)
                                                        }
                                                    }

                                                    val thumbnailImageView = ImageView(this@MainActivity).apply {
                                                        setImageResource(imageResId)
                                                        layoutParams = LinearLayout.LayoutParams(200, 200)
                                                        background = ContextCompat.getDrawable(this@MainActivity, android.R.drawable.dialog_holo_light_frame)
                                                        setPadding(8, 8, 8, 8)
                                                        setOnClickListener {
                                                            this.setBackgroundColor(android.graphics.Color.parseColor("#4CAF50")) // vert
                                                            postDelayed({
                                                                clickedZone.linkedImage = name
                                                                drawingView.invalidate()
                                                                modifyAlertDialog.dismiss()
                                                            }, 150)
                                                        }
                                                    }

                                                    val label = android.widget.TextView(this@MainActivity).apply {
                                                        text = name
                                                        gravity = Gravity.CENTER
                                                    }

                                                    imageContainer.addView(thumbnailImageView)
                                                    imageContainer.addView(label)
                                                    modifyImageDialogLayout.addView(imageContainer)
                                                }

                                                modifyAlertDialog.show()
                                            }
                                            Log.d("MainActivity", "Zone added: $rect -> $name")
                                            alertDialog.dismiss()
                                        }, 150)
                                    }
                                }

                                val label = android.widget.TextView(this@MainActivity).apply {
                                    text = name
                                    gravity = Gravity.CENTER
                                }

                                imageContainer.addView(thumbnailImageView)
                                imageContainer.addView(label)
                                linkedImageDialogLayout.addView(imageContainer)
                            }

                            alertDialog.show()
                        }
                        imageView.performClick()
                        drawing = false
                    }
                }
            }
            true
        }

        saveButton.setOnClickListener {
            Log.d("MainActivity", "Button clicked")
            saveConfig()
            startActivity(Intent(this, NavigatorActivity::class.java))
        }
    }

    private fun adjustCoordinates(imageView: ImageView, x: Float, y: Float): FloatArray {
        val imageX = x / imageView.width
        val imageY = y / imageView.height
        return floatArrayOf(imageX, imageY)
    }

    private fun saveConfig() {
        val json = JSONObject()
        val zonesJson = JSONObject()
        imageZones.forEach { (image, zoneList) ->
            val array = JSONArray()
            zoneList.forEach { zone ->
                val imageView = findViewById<ImageView>(R.id.configImageView)
                val width = imageView.width.toFloat().takeIf { it > 0 } ?: 1f
                val height = imageView.height.toFloat().takeIf { it > 0 } ?: 1f

                val z = JSONObject().apply {
                put("x1", zone.rect.left / width)
                    put("y1", zone.rect.top / height)
                    put("x2", zone.rect.right / width)
                    put("y2", zone.rect.bottom / height)
                    put("linkedImage", zone.linkedImage)
                }
                Log.d("MainActivity", "Zone sauvegardée (relative): $z")
                array.put(z)
            }
            zonesJson.put(image, array)
        }
        json.put("zones", zonesJson)
        json.put("startImage", "image1")

        val file = File(filesDir, "config.json")
        try {
            file.writeText(json.toString())
            Log.d("MainActivity", "Config saved: $json")
        } catch (e: Exception) {
            Log.e("MainActivity", "Failed to save config: $e")
        }
    }
}